# TokoKu v3.4

TokoKu aplikasi manajemen toko offline.

Fitur tambahan v3.4:
- Dari Detail Pelanggan tersedia tombol Tambah Pembelian / Item Produk.
- Pelanggan otomatis dipilih saat masuk ke Kasir dari Detail Pelanggan.
- Riwayat setiap pembelian pelanggan menampilkan item produk, jumlah, harga/unit, subtotal, dan total transaksi.
- Fitur sebelumnya tetap dipertahankan: logo toko, foto produk/pelanggan, detail Rumah Makan, hapus produk, struk WhatsApp, cetak 58/80 mm, stok, penjualan, piutang, laporan, supplier, retur, dan stok opname.
