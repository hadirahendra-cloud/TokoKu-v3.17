package com.tokoku.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.content.Intent;
import android.content.Context;
import android.net.Uri;
import androidx.core.content.FileProvider;
import android.util.Base64;
import java.io.File;
import java.io.FileOutputStream;
import android.view.Window;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.print.PrintDocumentAdapter;
import android.os.Build;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST = 1001;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent intent;
                try {
                    intent = params.createIntent();
                } catch (Exception e) {
                    intent = new Intent(Intent.ACTION_GET_CONTENT);
                    intent.setType("image/*");
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                }
                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                    return true;
                } catch (Exception e) {
                    filePathCallback = null;
                    return false;
                }
            }
        });
        webView.addJavascriptInterface(new ShareBridge(), "AndroidShare");
        webView.addJavascriptInterface(new PrintBridge(), "AndroidPrint");
        webView.loadUrl("file:///android_asset/index.html");
        setContentView(webView);
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST && filePathCallback != null) {
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int count = data.getClipData().getItemCount();
                    results = new Uri[count];
                    for (int i = 0; i < count; i++) results[i] = data.getClipData().getItemAt(i).getUri();
                } else if (data.getData() != null) {
                    results = new Uri[]{data.getData()};
                }
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
    }

    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    public class ShareBridge {
        @JavascriptInterface public void share(final String text) {
            runOnUiThread(new Runnable() { @Override public void run() {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain"); i.putExtra(Intent.EXTRA_TEXT, text);
                startActivity(Intent.createChooser(i, "Bagikan nota"));
            }});
        }
        @JavascriptInterface public void sendWhatsAppImage(final String dataUrl, final String phone, final String caption) {
            runOnUiThread(new Runnable() { @Override public void run() {
                try {
                    String base64 = dataUrl;
                    int comma = base64.indexOf(',');
                    if (comma >= 0) base64 = base64.substring(comma + 1);
                    byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                    File dir = new File(getCacheDir(), "shared_images");
                    if (!dir.exists()) dir.mkdirs();
                    File image = new File(dir, "nota-tokoku-" + System.currentTimeMillis() + ".jpg");
                    FileOutputStream out = new FileOutputStream(image);
                    out.write(bytes); out.flush(); out.close();
                    Uri uri = FileProvider.getUriForFile(MainActivity.this, "com.tokoku.app.fileprovider", image);
                    Intent i = new Intent(Intent.ACTION_SEND);
                    i.setType("image/jpeg");
                    i.putExtra(Intent.EXTRA_STREAM, uri);
                    i.putExtra(Intent.EXTRA_TEXT, caption == null ? "" : caption);
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try {
                        i.setPackage("com.whatsapp");
                        startActivity(i);
                    } catch (Exception ex) {
                        i.setPackage(null);
                        startActivity(Intent.createChooser(i, "Kirim nota digital"));
                    }
                } catch (Exception e) {
                    Intent i = new Intent(Intent.ACTION_SEND);
                    i.setType("text/plain");
                    i.putExtra(Intent.EXTRA_TEXT, caption == null ? "Nota TokoKu" : caption);
                    startActivity(Intent.createChooser(i, "Kirim nota"));
                }
            }});
        }

        @JavascriptInterface public void sendWhatsApp(final String text, final String phone) {
            runOnUiThread(new Runnable() { @Override public void run() {
                try {
                    if (phone != null && !phone.isEmpty()) {
                        String url = "https://wa.me/" + phone + "?text=" + URLEncoder.encode(text, "UTF-8");
                        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                        i.setPackage("com.whatsapp");
                        startActivity(i);
                    } else {
                        Intent i = new Intent(Intent.ACTION_SEND);
                        i.setType("text/plain");
                        i.putExtra(Intent.EXTRA_TEXT, text);
                        i.setPackage("com.whatsapp");
                        startActivity(i);
                    }
                } catch (Exception e) {
                    Intent i = new Intent(Intent.ACTION_SEND);
                    i.setType("text/plain");
                    i.putExtra(Intent.EXTRA_TEXT, text);
                    startActivity(Intent.createChooser(i, "Kirim nota ke WhatsApp"));
                }
            }});
        }
    }

    public class PrintBridge {
        @JavascriptInterface public void printReceipt(final String text, final String widthText) {
            runOnUiThread(new Runnable() { @Override public void run() {
                final int widthMm;
                try { widthMm = Integer.parseInt(widthText); } catch (Exception e) { return; }
                final WebView printWebView = new WebView(MainActivity.this);
                WebSettings ps = printWebView.getSettings();
                ps.setJavaScriptEnabled(true);
                printWebView.setWebViewClient(new WebViewClient() {
                    @Override public void onPageFinished(WebView view, String url) {
                        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.KITKAT) return;
                        PrintManager pm = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                        String jobName = "TokoKu Struk " + widthMm + "mm";
                        PrintDocumentAdapter adapter = printWebView.createPrintDocumentAdapter(jobName);
                        int widthMils = widthMm == 80 ? 3150 : 2283;
                        PrintAttributes.MediaSize media = new PrintAttributes.MediaSize(
                                widthMm == 80 ? "TOKO_80" : "TOKO_58",
                                widthMm == 80 ? "80mm" : "58mm",
                                widthMils, 11000);
                        PrintAttributes attrs = new PrintAttributes.Builder()
                                .setMediaSize(media)
                                .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                                .build();
                        pm.print(jobName, adapter, attrs);
                    }
                });
                String safe = escapeHtml(text);
                String html = "<!doctype html><html><head><meta charset='utf-8'><style>" +
                        "@page{size:" + widthMm + "mm auto;margin:0}" +
                        "html,body{margin:0;padding:0;background:#fff}" +
                        "pre{font-family:monospace;font-size:11px;line-height:1.25;white-space:pre-wrap;word-break:break-word;width:" +
                        (widthMm - 6) + "mm;margin:3mm auto}" +
                        "</style></head><body><pre>" + safe + "</pre></body></html>";
                printWebView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);
            }});
        }
    }

    private static String escapeHtml(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }
}
