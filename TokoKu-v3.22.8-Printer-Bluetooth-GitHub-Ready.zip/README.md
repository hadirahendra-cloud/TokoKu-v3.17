# TokoKu v3.4

TokoKu aplikasi manajemen toko offline.

Fitur tambahan v3.4:
- Dari Detail Pelanggan tersedia tombol Tambah Pembelian / Item Produk.
- Pelanggan otomatis dipilih saat masuk ke Kasir dari Detail Pelanggan.
- Riwayat setiap pembelian pelanggan menampilkan item produk, jumlah, harga/unit, subtotal, dan total transaksi.
- Fitur sebelumnya tetap dipertahankan: logo toko, foto produk/pelanggan, detail Rumah Makan, hapus produk, struk WhatsApp, cetak 58/80 mm, stok, penjualan, piutang, laporan, supplier, retur, dan stok opname.

## Splash fix
Splash RangMudo Jr. is held for a minimum of 3 seconds before TokoKu is shown.


## TokoKu v3.22.7 — Manual Jumlah Pembelian
- Kasir kini memiliki kolom **Jumlah beli** pada setiap produk.
- Masukkan jumlah secara manual lalu tekan **＋ Tambah**.
- Jumlah item di keranjang juga dapat diedit langsung melalui kolom angka.
- Fitur stok kosong/negatif tetap dipertahankan.
