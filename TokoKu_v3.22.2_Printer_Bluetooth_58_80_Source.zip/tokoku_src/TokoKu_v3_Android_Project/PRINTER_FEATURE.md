# TokoKu v3.22.2 — Pengaturan Printer

Fitur yang ditambahkan:
- Setelan → Printer Nota
- Menampilkan printer Bluetooth yang sudah dipasangkan dengan HP
- Memilih printer dan menyimpan alamat Bluetooth
- Pilihan kertas 58 mm / 80 mm
- Test Print
- Tombol membuka Pengaturan Bluetooth HP
- Cetak nota langsung melalui Bluetooth menggunakan ESC/POS SPP
- Jika printer Bluetooth belum dipilih, tombol cetak tetap memakai Android Print Framework seperti sebelumnya

Catatan: printer thermal Bluetooth harus dipasangkan terlebih dahulu di Pengaturan Bluetooth Android. Fitur ini memakai koneksi Bluetooth Classic SPP (UUID 00001101-0000-1000-8000-00805F9B34FB), yang umum digunakan printer thermal ESC/POS.
