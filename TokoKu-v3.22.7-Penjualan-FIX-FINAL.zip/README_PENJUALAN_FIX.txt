TokoKu v3.22.7 - Penjualan FIX FINAL

Perbaikan:
1. Akses Cepat -> Penjualan memakai data db.sales yang sama dengan Riwayat Transaksi.
2. Ringkasan Toko -> Penjualan hari ini memakai parser tanggal transaksi yang benar,
   sehingga format tanggal Indonesia seperti "1/10/2026, 12.41.31" ikut terbaca.
3. Workflow build-apk.yml sudah dibuat self-contained dan tidak lagi mencari ZIP
   Master di dalam repository.

Build:
GitHub Actions -> Build TokoKu v3.22.7 - Penjualan FIX -> Run workflow.
