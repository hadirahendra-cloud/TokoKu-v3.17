TOKOKU v3.22.9 - GITHUB READY

1. Upload this folder's .github/workflows/build-tokoku-3.22.9-installable.yml to:
   .github/workflows/

2. Keep the source ZIP in the repository root with this exact name:
   TokoKu-v3.22.9-Printer-Bluetooth-GITHUB-READY.zip

3. The repository must already contain these GitHub Secrets:
   TOKOKU_KEYSTORE_BASE64
   TOKOKU_KEYSTORE_PASSWORD
   TOKOKU_KEY_ALIAS
   TOKOKU_KEY_PASSWORD

4. Run:
   Actions -> Build TokoKu v3.22.9 Installable -> Run workflow

5. Download artifact:
   TokoKu-v3.22.9-INSTALLABLE-SIGNED

The workflow explicitly signs the final APK with the TokoKu release keystore,
then verifies package name, versionCode/versionName and APK signature before upload.
Do NOT uninstall the existing TokoKu app before testing the update.
