package com.tokoku.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.content.Intent;
import android.content.Context;
import android.net.Uri;
import androidx.core.content.FileProvider;
import androidx.core.view.WindowCompat;
import android.util.Base64;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import android.view.Window;
import android.view.View;
import android.widget.LinearLayout;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.print.PrintDocumentAdapter;
import android.os.Build;
import android.os.Handler;
import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.provider.Settings;
import java.util.Set;
import java.util.UUID;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView webView;
    private LinearLayout splash;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST = 1001;
    private static final int BACKUP_CREATE_REQUEST = 1002;
    private static final int BLUETOOTH_PERMISSION_REQUEST = 1003;
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private final String PREFS = "tokoku_printer";
    private String pendingBackupJson;
    private static final long SPLASH_DURATION_MS = 3000L;
    private final Handler splashHandler = new Handler();
    private long splashStartTime;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), true);
        setContentView(R.layout.activity_main);
        splashStartTime = System.currentTimeMillis();
        webView = (WebView) findViewById(R.id.webview);
        splash = (LinearLayout) findViewById(R.id.splash);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                long elapsed = System.currentTimeMillis() - splashStartTime;
                long remaining = Math.max(0L, SPLASH_DURATION_MS - elapsed);
                if (splash != null) {
                    splashHandler.postDelayed(new Runnable() {
                        @Override public void run() {
                            if (splash != null) splash.setVisibility(View.GONE);
                        }
                    }, remaining);
                }
                getWindow().setStatusBarColor(android.graphics.Color.WHITE);
                getWindow().setNavigationBarColor(android.graphics.Color.WHITE);
                WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightStatusBars(true);
                WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightNavigationBars(true);
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent intent;
                try {
                    intent = params.createIntent();
                } catch (Exception e) {
                    intent = new Intent(Intent.ACTION_GET_CONTENT);
                    intent.setType("image/*");
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                }
                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                    return true;
                } catch (Exception e) {
                    filePathCallback = null;
                    return false;
                }
            }
        });
        webView.addJavascriptInterface(new ShareBridge(), "AndroidShare");
        webView.addJavascriptInterface(new BackupBridge(), "AndroidBackup");
        webView.addJavascriptInterface(new PrintBridge(), "AndroidPrint");
        webView.addJavascriptInterface(new PrinterBridge(), "AndroidPrinter");
        getWindow().setStatusBarColor(android.graphics.Color.WHITE);
        getWindow().setNavigationBarColor(android.graphics.Color.WHITE);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightStatusBars(true);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightNavigationBars(true);
        webView.loadUrl("file:///android_asset/index.html");
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == BACKUP_CREATE_REQUEST) {
            try {
                if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingBackupJson != null) {
                    Uri uri = data.getData();
                    try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                        if (out == null) throw new Exception("Tidak dapat membuka lokasi penyimpanan");
                        out.write(pendingBackupJson.getBytes(StandardCharsets.UTF_8));
                        out.flush();
                    }
                    webView.evaluateJavascript("if(window.onAndroidBackupSaved)window.onAndroidBackupSaved(true)", null);
                } else {
                    webView.evaluateJavascript("if(window.onAndroidBackupSaved)window.onAndroidBackupSaved(false)", null);
                }
            } catch (Exception e) {
                webView.evaluateJavascript("if(window.onAndroidBackupSaved)window.onAndroidBackupSaved(false)", null);
            } finally {
                pendingBackupJson = null;
            }
            return;
        }
        if (requestCode == FILE_CHOOSER_REQUEST && filePathCallback != null) {
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int count = data.getClipData().getItemCount();
                    results = new Uri[count];
                    for (int i = 0; i < count; i++) results[i] = data.getClipData().getItemAt(i).getUri();
                } else if (data.getData() != null) {
                    results = new Uri[]{data.getData()};
                }
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
    }

    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    public class BackupBridge {
        @JavascriptInterface public void saveBackup(final String json, final String filename) {
            runOnUiThread(new Runnable() { @Override public void run() {
                try {
                    pendingBackupJson = json == null ? "" : json;
                    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("application/json");
                    intent.putExtra(Intent.EXTRA_TITLE, filename == null || filename.isEmpty() ? "tokoku-backup.json" : filename);
                    startActivityForResult(intent, BACKUP_CREATE_REQUEST);
                } catch (Exception e) {
                    pendingBackupJson = null;
                    webView.evaluateJavascript("if(window.onAndroidBackupSaved)window.onAndroidBackupSaved(false)", null);
                }
            }});
        }
    }

    public class ShareBridge {
        @JavascriptInterface public void share(final String text) {
            runOnUiThread(new Runnable() { @Override public void run() {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain"); i.putExtra(Intent.EXTRA_TEXT, text);
                startActivity(Intent.createChooser(i, "Bagikan nota"));
            }});
        }
        @JavascriptInterface public void sendWhatsAppImage(final String dataUrl, final String phone, final String caption) {
            runOnUiThread(new Runnable() { @Override public void run() {
                try {
                    String base64 = dataUrl;
                    int comma = base64.indexOf(',');
                    if (comma >= 0) base64 = base64.substring(comma + 1);
                    byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                    File dir = new File(getCacheDir(), "shared_images");
                    if (!dir.exists()) dir.mkdirs();
                    File image = new File(dir, "nota-tokoku-" + System.currentTimeMillis() + ".jpg");
                    FileOutputStream out = new FileOutputStream(image);
                    out.write(bytes); out.flush(); out.close();
                    Uri uri = FileProvider.getUriForFile(MainActivity.this, "com.tokoku.app.fileprovider", image);
                    Intent i = new Intent(Intent.ACTION_SEND);
                    i.setType("image/jpeg");
                    i.putExtra(Intent.EXTRA_STREAM, uri);
                    i.putExtra(Intent.EXTRA_TEXT, caption == null ? "" : caption);
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try {
                        i.setPackage("com.whatsapp");
                        startActivity(i);
                    } catch (Exception ex) {
                        i.setPackage(null);
                        startActivity(Intent.createChooser(i, "Kirim nota digital"));
                    }
                } catch (Exception e) {
                    Intent i = new Intent(Intent.ACTION_SEND);
                    i.setType("text/plain");
                    i.putExtra(Intent.EXTRA_TEXT, caption == null ? "Nota TokoKu" : caption);
                    startActivity(Intent.createChooser(i, "Kirim nota"));
                }
            }});
        }

        @JavascriptInterface public void sendWhatsApp(final String text, final String phone) {
            runOnUiThread(new Runnable() { @Override public void run() {
                try {
                    if (phone != null && !phone.isEmpty()) {
                        String url = "https://wa.me/" + phone + "?text=" + URLEncoder.encode(text, "UTF-8");
                        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                        i.setPackage("com.whatsapp");
                        startActivity(i);
                    } else {
                        Intent i = new Intent(Intent.ACTION_SEND);
                        i.setType("text/plain");
                        i.putExtra(Intent.EXTRA_TEXT, text);
                        i.setPackage("com.whatsapp");
                        startActivity(i);
                    }
                } catch (Exception e) {
                    Intent i = new Intent(Intent.ACTION_SEND);
                    i.setType("text/plain");
                    i.putExtra(Intent.EXTRA_TEXT, text);
                    startActivity(Intent.createChooser(i, "Kirim nota ke WhatsApp"));
                }
            }});
        }
    }

    public class PrinterBridge {
        private SharedPreferences prefs() { return getSharedPreferences(PREFS, MODE_PRIVATE); }

        @JavascriptInterface public String getSelectedPrinter() {
            return prefs().getString("printer", "");
        }

        @JavascriptInterface public void savePrinter(final String address, final String name, final String width) {
            prefs().edit().putString("printer", address == null ? "" : address)
                    .putString("printerName", name == null ? "" : name)
                    .putString("paperWidth", ("80".equals(width) ? "80" : "58"))
                    .apply();
        }

        @JavascriptInterface public String getPaperWidth() {
            return prefs().getString("paperWidth", "58");
        }

        @JavascriptInterface public void requestBluetoothPermission() {
            if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN}, BLUETOOTH_PERMISSION_REQUEST);
            }
        }

        @JavascriptInterface public String getPairedPrinters() {
            try {
                if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) return "[]";
                BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
                if (adapter == null) return "[]";
                Set<BluetoothDevice> devices = adapter.getBondedDevices();
                StringBuilder out = new StringBuilder("[");
                boolean first = true;
                for (BluetoothDevice d : devices) {
                    String name;
                    try { name = d.getName(); } catch (SecurityException e) { name = "Bluetooth"; }
                    String address = d.getAddress();
                    if (!first) out.append(',');
                    first = false;
                    out.append("{\"name\":\"").append(jsonEscape(name == null ? "Printer Bluetooth" : name))
                       .append("\",\"address\":\"").append(jsonEscape(address == null ? "" : address)).append("\"}");
                }
                return out.append(']').toString();
            } catch (Exception e) { return "[]"; }
        }

        @JavascriptInterface public void openBluetoothSettings() {
            try { startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS)); } catch (Exception ignored) {}
        }

        @JavascriptInterface public void testPrint(final String text, final String width) {
            printBluetooth(text, width, true);
        }

        private void printBluetooth(final String text, final String width, final boolean showResult) {
            new Thread(new Runnable() {
                @Override public void run() {
                    String result = "";
                    try {
                        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                            result = "IZIN Bluetooth belum diberikan. Tekan Izinkan Bluetooth.";
                        } else {
                            String address = prefs().getString("printer", "");
                            if (address.isEmpty()) throw new Exception("Printer belum dipilih");
                            BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
                            if (adapter == null) throw new Exception("Bluetooth tidak tersedia");
                            if (!adapter.isEnabled()) throw new Exception("Bluetooth belum aktif");
                            BluetoothDevice device = adapter.getRemoteDevice(address);
                            BluetoothSocket socket = device.createRfcommSocketToServiceRecord(SPP_UUID);
                            adapter.cancelDiscovery();
                            socket.connect();
                            OutputStream out = socket.getOutputStream();
                            out.write(new byte[]{0x1B,0x40});
                            out.write(buildEscPos(text, "80".equals(width) ? 80 : 58));
                            out.write(new byte[]{0x0A,0x0A,0x0A,0x1D,0x56,0x00});
                            out.flush(); out.close(); socket.close();
                            result = "OK";
                        }
                    } catch (Exception e) { result = e.getMessage() == null ? "Gagal mencetak" : e.getMessage(); }
                    if (showResult) {
                        final String r = result;
                        runOnUiThread(new Runnable(){ public void run(){
                            webView.evaluateJavascript("if(window.onPrinterTestResult)window.onPrinterTestResult(" + jsQuote(r) + ")", null);
                        }});
                    }
                }
            }).start();
        }

        private byte[] buildEscPos(String text, int width) throws Exception {
            String normalized = text == null ? "" : text.replace("\r", "");
            int maxChars = width == 80 ? 48 : 32;
            StringBuilder wrapped = new StringBuilder();
            for (String line : normalized.split("\\n", -1)) {
                if (line.length() <= maxChars) wrapped.append(line).append('\n');
                else {
                    for (int i=0;i<line.length();i+=maxChars) wrapped.append(line, i, Math.min(i+maxChars,line.length())).append('\n');
                }
            }
            return wrapped.toString().getBytes("CP437");
        }
    }

    public class PrintBridge {
        @JavascriptInterface public void printReceipt(final String text, final String widthText) {
            runOnUiThread(new Runnable() { @Override public void run() {
                final int widthMm;
                try { widthMm = Integer.parseInt(widthText); } catch (Exception e) { return; }
                SharedPreferences pp = getSharedPreferences(PREFS, MODE_PRIVATE);
                if (!pp.getString("printer", "").isEmpty()) {
                    new PrinterBridge().printBluetooth(text, String.valueOf(widthMm), true);
                    return;
                }
                final WebView printWebView = new WebView(MainActivity.this);
                WebSettings ps = printWebView.getSettings();
                ps.setJavaScriptEnabled(true);
                printWebView.setWebViewClient(new WebViewClient() {
                    @Override public void onPageFinished(WebView view, String url) {
                        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.KITKAT) return;
                        PrintManager pm = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                        String jobName = "TokoKu Struk " + widthMm + "mm";
                        PrintDocumentAdapter adapter = printWebView.createPrintDocumentAdapter(jobName);
                        int widthMils = widthMm == 80 ? 3150 : 2283;
                        PrintAttributes.MediaSize media = new PrintAttributes.MediaSize(
                                widthMm == 80 ? "TOKO_80" : "TOKO_58",
                                widthMm == 80 ? "80mm" : "58mm",
                                widthMils, 11000);
                        PrintAttributes attrs = new PrintAttributes.Builder()
                                .setMediaSize(media)
                                .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                                .build();
                        pm.print(jobName, adapter, attrs);
                    }
                });
                String safe = escapeHtml(text);
                String html = "<!doctype html><html><head><meta charset='utf-8'><style>" +
                        "@page{size:" + widthMm + "mm auto;margin:0}" +
                        "html,body{margin:0;padding:0;background:#fff}" +
                        "pre{font-family:monospace;font-size:11px;line-height:1.25;white-space:pre-wrap;word-break:break-word;width:" +
                        (widthMm - 6) + "mm;margin:3mm auto}" +
                        "</style></head><body><pre>" + safe + "</pre></body></html>";
                printWebView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);
            }});
        }
    }

    private static String jsonEscape(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r");
    }
    private static String jsQuote(String s) {
        return "\"" + jsonEscape(s) + "\"";
    }

    private static String escapeHtml(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }
}
