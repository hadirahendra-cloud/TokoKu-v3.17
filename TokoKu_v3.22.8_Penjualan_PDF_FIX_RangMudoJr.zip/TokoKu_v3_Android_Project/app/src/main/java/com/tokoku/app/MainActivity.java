package com.tokoku.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.content.Intent;
import android.content.Context;
import android.net.Uri;
import androidx.core.content.FileProvider;
import androidx.core.view.WindowCompat;
import android.util.Base64;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import android.view.Window;
import android.view.View;
import android.widget.LinearLayout;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.print.PrintDocumentAdapter;
import android.os.Build;
import android.os.Handler;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView webView;
    private LinearLayout splash;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST = 1001;
    private static final int BACKUP_CREATE_REQUEST = 1002;
    private String pendingBackupJson;
    private static final long SPLASH_DURATION_MS = 3000L;
    private final Handler splashHandler = new Handler();
    private long splashStartTime;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), true);
        setContentView(R.layout.activity_main);
        splashStartTime = System.currentTimeMillis();
        webView = (WebView) findViewById(R.id.webview);
        splash = (LinearLayout) findViewById(R.id.splash);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                long elapsed = System.currentTimeMillis() - splashStartTime;
                long remaining = Math.max(0L, SPLASH_DURATION_MS - elapsed);
                if (splash != null) {
                    splashHandler.postDelayed(new Runnable() {
                        @Override public void run() {
                            if (splash != null) splash.setVisibility(View.GONE);
                        }
                    }, remaining);
                }
                getWindow().setStatusBarColor(android.graphics.Color.WHITE);
                getWindow().setNavigationBarColor(android.graphics.Color.WHITE);
                WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightStatusBars(true);
                WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightNavigationBars(true);
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent intent;
                try {
                    intent = params.createIntent();
                } catch (Exception e) {
                    intent = new Intent(Intent.ACTION_GET_CONTENT);
                    intent.setType("image/*");
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                }
                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                    return true;
                } catch (Exception e) {
                    filePathCallback = null;
                    return false;
                }
            }
        });
        webView.addJavascriptInterface(new ShareBridge(), "AndroidShare");
        webView.addJavascriptInterface(new BackupBridge(), "AndroidBackup");
        webView.addJavascriptInterface(new PrintBridge(), "AndroidPrint");
        getWindow().setStatusBarColor(android.graphics.Color.WHITE);
        getWindow().setNavigationBarColor(android.graphics.Color.WHITE);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightStatusBars(true);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightNavigationBars(true);
        webView.loadUrl("file:///android_asset/index.html");
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == BACKUP_CREATE_REQUEST) {
            try {
                if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingBackupJson != null) {
                    Uri uri = data.getData();
                    try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                        if (out == null) throw new Exception("Tidak dapat membuka lokasi penyimpanan");
                        out.write(pendingBackupJson.getBytes(StandardCharsets.UTF_8));
                        out.flush();
                    }
                    webView.evaluateJavascript("if(window.onAndroidBackupSaved)window.onAndroidBackupSaved(true)", null);
                } else {
                    webView.evaluateJavascript("if(window.onAndroidBackupSaved)window.onAndroidBackupSaved(false)", null);
                }
            } catch (Exception e) {
                webView.evaluateJavascript("if(window.onAndroidBackupSaved)window.onAndroidBackupSaved(false)", null);
            } finally {
                pendingBackupJson = null;
            }
            return;
        }
        if (requestCode == FILE_CHOOSER_REQUEST && filePathCallback != null) {
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int count = data.getClipData().getItemCount();
                    results = new Uri[count];
                    for (int i = 0; i < count; i++) results[i] = data.getClipData().getItemAt(i).getUri();
                } else if (data.getData() != null) {
                    results = new Uri[]{data.getData()};
                }
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
    }

    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    public class BackupBridge {
        @JavascriptInterface public void saveBackup(final String json, final String filename) {
            runOnUiThread(new Runnable() { @Override public void run() {
                try {
                    pendingBackupJson = json == null ? "" : json;
                    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("application/json");
                    intent.putExtra(Intent.EXTRA_TITLE, filename == null || filename.isEmpty() ? "tokoku-backup.json" : filename);
                    startActivityForResult(intent, BACKUP_CREATE_REQUEST);
                } catch (Exception e) {
                    pendingBackupJson = null;
                    webView.evaluateJavascript("if(window.onAndroidBackupSaved)window.onAndroidBackupSaved(false)", null);
                }
            }});
        }
    }

    public class ShareBridge {
        @JavascriptInterface public void share(final String text) {
            runOnUiThread(new Runnable() { @Override public void run() {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain"); i.putExtra(Intent.EXTRA_TEXT, text);
                startActivity(Intent.createChooser(i, "Bagikan nota"));
            }});
        }
        @JavascriptInterface public void sendWhatsAppImage(final String dataUrl, final String phone, final String caption) {
            runOnUiThread(new Runnable() { @Override public void run() {
                try {
                    String base64 = dataUrl;
                    int comma = base64.indexOf(',');
                    if (comma >= 0) base64 = base64.substring(comma + 1);
                    byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                    File dir = new File(getCacheDir(), "shared_images");
                    if (!dir.exists()) dir.mkdirs();
                    File image = new File(dir, "nota-tokoku-" + System.currentTimeMillis() + ".jpg");
                    FileOutputStream out = new FileOutputStream(image);
                    out.write(bytes); out.flush(); out.close();
                    Uri uri = FileProvider.getUriForFile(MainActivity.this, "com.tokoku.app.fileprovider", image);
                    Intent i = new Intent(Intent.ACTION_SEND);
                    i.setType("image/jpeg");
                    i.putExtra(Intent.EXTRA_STREAM, uri);
                    i.putExtra(Intent.EXTRA_TEXT, caption == null ? "" : caption);
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try {
                        i.setPackage("com.whatsapp");
                        startActivity(i);
                    } catch (Exception ex) {
                        i.setPackage(null);
                        startActivity(Intent.createChooser(i, "Kirim nota digital"));
                    }
                } catch (Exception e) {
                    Intent i = new Intent(Intent.ACTION_SEND);
                    i.setType("text/plain");
                    i.putExtra(Intent.EXTRA_TEXT, caption == null ? "Nota TokoKu" : caption);
                    startActivity(Intent.createChooser(i, "Kirim nota"));
                }
            }});
        }

        @JavascriptInterface public void sendWhatsApp(final String text, final String phone) {
            runOnUiThread(new Runnable() { @Override public void run() {
                try {
                    if (phone != null && !phone.isEmpty()) {
                        String url = "https://wa.me/" + phone + "?text=" + URLEncoder.encode(text, "UTF-8");
                        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                        i.setPackage("com.whatsapp");
                        startActivity(i);
                    } else {
                        Intent i = new Intent(Intent.ACTION_SEND);
                        i.setType("text/plain");
                        i.putExtra(Intent.EXTRA_TEXT, text);
                        i.setPackage("com.whatsapp");
                        startActivity(i);
                    }
                } catch (Exception e) {
                    Intent i = new Intent(Intent.ACTION_SEND);
                    i.setType("text/plain");
                    i.putExtra(Intent.EXTRA_TEXT, text);
                    startActivity(Intent.createChooser(i, "Kirim nota ke WhatsApp"));
                }
            }});
        }
    }

    public class PrintBridge {
        @JavascriptInterface public void printCurrentPage() {
            runOnUiThread(new Runnable() { @Override public void run() {
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.KITKAT) {
                    webView.evaluateJavascript("window.print()", null);
                    return;
                }
                try {
                    PrintManager pm = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                    PrintDocumentAdapter adapter = webView.createPrintDocumentAdapter("TokoKu");
                    PrintAttributes attrs = new PrintAttributes.Builder()
                            .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                            .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                            .build();
                    pm.print("TokoKu - Cetak / Simpan PDF", adapter, attrs);
                } catch (Exception e) {
                    webView.evaluateJavascript("if(window.toast)toast('Gagal membuka dialog cetak')", null);
                }
            }});
        }

        @JavascriptInterface public void printReceipt(final String text, final String widthText) {
            runOnUiThread(new Runnable() { @Override public void run() {
                final int widthMm;
                try { widthMm = Integer.parseInt(widthText); } catch (Exception e) { return; }
                final WebView printWebView = new WebView(MainActivity.this);
                WebSettings ps = printWebView.getSettings();
                ps.setJavaScriptEnabled(true);
                printWebView.setWebViewClient(new WebViewClient() {
                    @Override public void onPageFinished(WebView view, String url) {
                        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.KITKAT) return;
                        PrintManager pm = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                        String jobName = "TokoKu Struk " + widthMm + "mm";
                        PrintDocumentAdapter adapter = printWebView.createPrintDocumentAdapter(jobName);
                        int widthMils = widthMm == 80 ? 3150 : 2283;
                        PrintAttributes.MediaSize media = new PrintAttributes.MediaSize(
                                widthMm == 80 ? "TOKO_80" : "TOKO_58",
                                widthMm == 80 ? "80mm" : "58mm",
                                widthMils, 11000);
                        PrintAttributes attrs = new PrintAttributes.Builder()
                                .setMediaSize(media)
                                .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                                .build();
                        pm.print(jobName, adapter, attrs);
                    }
                });
                String safe = escapeHtml(text);
                String html = "<!doctype html><html><head><meta charset='utf-8'><style>" +
                        "@page{size:" + widthMm + "mm auto;margin:0}" +
                        "html,body{margin:0;padding:0;background:#fff}" +
                        "pre{font-family:monospace;font-size:11px;line-height:1.25;white-space:pre-wrap;word-break:break-word;width:" +
                        (widthMm - 6) + "mm;margin:3mm auto}" +
                        "</style></head><body><pre>" + safe + "</pre></body></html>";
                printWebView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);
            }});
        }
    }

    private static String escapeHtml(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }
}
